Thank you for choosing us<br>
<br>
You are successfully registered with <a target="_blank" href="https://www.krishnachikanindustry.com/">krishnachikanindustry</a>.<br>
Your login credentials are:<br>
Email: <?php echo $email; ?><br>
Password: As you submitted<br>